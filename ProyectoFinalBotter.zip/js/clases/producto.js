
class Producto{

    constructor(nombre,precio,tipo,codigo,urlImg){
        this.nombre = nombre;
        this.precio = precio;
        this.tipo = tipo;
        this.codigo = codigo;
        this.urlImg = urlImg;
        this.cantidad = 1;        
    }

}